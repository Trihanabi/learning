package com.joe.MybatisApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
